namespace Stacky
{
    public class PagerInfo
    {
        public int CurrentPage { get; set; }
        public int PageSize { get; set; }
    }
}