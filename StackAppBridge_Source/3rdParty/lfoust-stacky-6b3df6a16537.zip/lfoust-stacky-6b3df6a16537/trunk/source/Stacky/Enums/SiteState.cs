﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Stacky
{
    public enum SiteState
    {
        Normal,
        Closed_Beta,
        Open_Beta,
        Linked_Meta
    }
}
