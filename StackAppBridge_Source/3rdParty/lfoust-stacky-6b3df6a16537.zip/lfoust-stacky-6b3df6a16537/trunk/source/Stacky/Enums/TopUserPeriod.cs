﻿namespace Stacky
{
    public enum TopUserPeriod
    {
        [SortArgs("all-time")]
        AllTime,
        [SortArgs("month")]
        Month
    }
}