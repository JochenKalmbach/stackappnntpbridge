﻿using System;

namespace Stacky
{
    public class BadgeByUserOptions
    {
        public int? Page = null;
        public int? PageSize = null;
        public DateTime? FromDate = null;
        public DateTime? ToDate = null;
    }
}