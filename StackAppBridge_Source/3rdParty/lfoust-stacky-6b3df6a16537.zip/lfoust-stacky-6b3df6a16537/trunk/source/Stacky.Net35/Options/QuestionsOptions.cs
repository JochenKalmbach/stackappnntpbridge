﻿namespace Stacky
{
    public class QuestionOptions : QuestionsOptionBase<QuestionSort>
    {
        public QuestionOptions()
            : base(QuestionSort.Activity)
        {
        }
    }
}